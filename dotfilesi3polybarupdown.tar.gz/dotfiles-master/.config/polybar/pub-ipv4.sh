#!/bin/bash

echo $(curl -s https://ipinfo.io/ip)
