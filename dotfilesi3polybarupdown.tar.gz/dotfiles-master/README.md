# dotfiles
My dotfiles for i3-gaps-rounded with Rofi, Polybar, Compton as the screen compositor.
